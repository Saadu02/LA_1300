﻿namespace Game
{
    partial class Two_Players
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.A00 = new System.Windows.Forms.Button();
            this.A01 = new System.Windows.Forms.Button();
            this.A02 = new System.Windows.Forms.Button();
            this.A10 = new System.Windows.Forms.Button();
            this.A11 = new System.Windows.Forms.Button();
            this.A12 = new System.Windows.Forms.Button();
            this.A20 = new System.Windows.Forms.Button();
            this.A21 = new System.Windows.Forms.Button();
            this.A22 = new System.Windows.Forms.Button();
            this.Ibl_x = new System.Windows.Forms.Label();
            this.Ibl_y = new System.Windows.Forms.Label();
            this.Ibl_draw = new System.Windows.Forms.Label();
            this.Btn_NG = new System.Windows.Forms.Button();
            this.Btn_Reset = new System.Windows.Forms.Button();
            this.Btn_End = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // A00
            // 
            this.A00.Location = new System.Drawing.Point(53, 120);
            this.A00.Name = "A00";
            this.A00.Size = new System.Drawing.Size(150, 150);
            this.A00.TabIndex = 0;
            this.A00.UseVisualStyleBackColor = true;
            this.A00.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // A01
            // 
            this.A01.Location = new System.Drawing.Point(209, 120);
            this.A01.Name = "A01";
            this.A01.Size = new System.Drawing.Size(150, 150);
            this.A01.TabIndex = 1;
            this.A01.UseVisualStyleBackColor = true;
            this.A01.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // A02
            // 
            this.A02.Location = new System.Drawing.Point(365, 120);
            this.A02.Name = "A02";
            this.A02.Size = new System.Drawing.Size(150, 150);
            this.A02.TabIndex = 2;
            this.A02.UseVisualStyleBackColor = true;
            this.A02.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // A10
            // 
            this.A10.Location = new System.Drawing.Point(53, 276);
            this.A10.Name = "A10";
            this.A10.Size = new System.Drawing.Size(150, 150);
            this.A10.TabIndex = 3;
            this.A10.UseVisualStyleBackColor = true;
            this.A10.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // A11
            // 
            this.A11.Location = new System.Drawing.Point(209, 276);
            this.A11.Name = "A11";
            this.A11.Size = new System.Drawing.Size(150, 150);
            this.A11.TabIndex = 4;
            this.A11.UseVisualStyleBackColor = true;
            this.A11.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // A12
            // 
            this.A12.Location = new System.Drawing.Point(365, 276);
            this.A12.Name = "A12";
            this.A12.Size = new System.Drawing.Size(150, 150);
            this.A12.TabIndex = 5;
            this.A12.UseVisualStyleBackColor = true;
            this.A12.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // A20
            // 
            this.A20.Location = new System.Drawing.Point(53, 432);
            this.A20.Name = "A20";
            this.A20.Size = new System.Drawing.Size(150, 150);
            this.A20.TabIndex = 6;
            this.A20.UseVisualStyleBackColor = true;
            this.A20.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // A21
            // 
            this.A21.Location = new System.Drawing.Point(209, 432);
            this.A21.Name = "A21";
            this.A21.Size = new System.Drawing.Size(150, 150);
            this.A21.TabIndex = 7;
            this.A21.UseVisualStyleBackColor = true;
            this.A21.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // A22
            // 
            this.A22.Location = new System.Drawing.Point(365, 432);
            this.A22.Name = "A22";
            this.A22.Size = new System.Drawing.Size(150, 150);
            this.A22.TabIndex = 8;
            this.A22.UseVisualStyleBackColor = true;
            this.A22.Click += new System.EventHandler(this.ButtonsClick);
            // 
            // Ibl_x
            // 
            this.Ibl_x.AutoSize = true;
            this.Ibl_x.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ibl_x.Location = new System.Drawing.Point(636, 120);
            this.Ibl_x.Name = "Ibl_x";
            this.Ibl_x.Size = new System.Drawing.Size(49, 37);
            this.Ibl_x.TabIndex = 9;
            this.Ibl_x.Text = "X:";
            // 
            // Ibl_y
            // 
            this.Ibl_y.AutoSize = true;
            this.Ibl_y.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ibl_y.Location = new System.Drawing.Point(636, 174);
            this.Ibl_y.Name = "Ibl_y";
            this.Ibl_y.Size = new System.Drawing.Size(50, 37);
            this.Ibl_y.TabIndex = 10;
            this.Ibl_y.Text = "Y:";
            // 
            // Ibl_draw
            // 
            this.Ibl_draw.AutoSize = true;
            this.Ibl_draw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ibl_draw.Location = new System.Drawing.Point(579, 233);
            this.Ibl_draw.Name = "Ibl_draw";
            this.Ibl_draw.Size = new System.Drawing.Size(106, 37);
            this.Ibl_draw.TabIndex = 11;
            this.Ibl_draw.Text = "Draw:";
            // 
            // Btn_NG
            // 
            this.Btn_NG.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Btn_NG.Location = new System.Drawing.Point(563, 276);
            this.Btn_NG.Name = "Btn_NG";
            this.Btn_NG.Size = new System.Drawing.Size(267, 96);
            this.Btn_NG.TabIndex = 12;
            this.Btn_NG.Text = "New Game";
            this.Btn_NG.UseVisualStyleBackColor = false;
            this.Btn_NG.Click += new System.EventHandler(this.Btn_NG_Click);
            // 
            // Btn_Reset
            // 
            this.Btn_Reset.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Btn_Reset.Location = new System.Drawing.Point(563, 378);
            this.Btn_Reset.Name = "Btn_Reset";
            this.Btn_Reset.Size = new System.Drawing.Size(267, 96);
            this.Btn_Reset.TabIndex = 13;
            this.Btn_Reset.Text = "Reset";
            this.Btn_Reset.UseVisualStyleBackColor = false;
            this.Btn_Reset.Click += new System.EventHandler(this.Btn_Reset_Click);
            // 
            // Btn_End
            // 
            this.Btn_End.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Btn_End.Location = new System.Drawing.Point(563, 480);
            this.Btn_End.Name = "Btn_End";
            this.Btn_End.Size = new System.Drawing.Size(267, 96);
            this.Btn_End.TabIndex = 14;
            this.Btn_End.Text = "End";
            this.Btn_End.UseVisualStyleBackColor = false;
            this.Btn_End.Click += new System.EventHandler(this.Btn_End_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(728, 620);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(259, 42);
            this.label5.TabIndex = 15;
            this.label5.Text = "© by Brandon";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(181, 44);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(172, 31);
            this.textBox2.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 31);
            this.label1.TabIndex = 18;
            this.label1.Text = "Player O";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(359, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 31);
            this.label2.TabIndex = 19;
            this.label2.Text = "Player X";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(523, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(172, 31);
            this.textBox1.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Location = new System.Drawing.Point(53, 620);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 52);
            this.button1.TabIndex = 21;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Two_Players
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 684);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Btn_End);
            this.Controls.Add(this.Btn_Reset);
            this.Controls.Add(this.Btn_NG);
            this.Controls.Add(this.Ibl_draw);
            this.Controls.Add(this.Ibl_y);
            this.Controls.Add(this.Ibl_x);
            this.Controls.Add(this.A22);
            this.Controls.Add(this.A21);
            this.Controls.Add(this.A20);
            this.Controls.Add(this.A12);
            this.Controls.Add(this.A11);
            this.Controls.Add(this.A10);
            this.Controls.Add(this.A02);
            this.Controls.Add(this.A01);
            this.Controls.Add(this.A00);
            this.Name = "Two_Players";
            this.Text = "Two_Players";
            this.Load += new System.EventHandler(this.Two_Players_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button A00;
        private System.Windows.Forms.Button A01;
        private System.Windows.Forms.Button A02;
        private System.Windows.Forms.Button A10;
        private System.Windows.Forms.Button A11;
        private System.Windows.Forms.Button A12;
        private System.Windows.Forms.Button A20;
        private System.Windows.Forms.Button A21;
        private System.Windows.Forms.Button A22;
        private System.Windows.Forms.Label Ibl_x;
        private System.Windows.Forms.Label Ibl_y;
        private System.Windows.Forms.Label Ibl_draw;
        private System.Windows.Forms.Button Btn_NG;
        private System.Windows.Forms.Button Btn_Reset;
        private System.Windows.Forms.Button Btn_End;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
    }
}